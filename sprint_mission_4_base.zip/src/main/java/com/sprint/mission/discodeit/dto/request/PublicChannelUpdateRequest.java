package com.sprint.mission.discodeit.dto.request;

public record PublicChannelUpdateRequest(
        String newName,
        String newDescription
) {
}
