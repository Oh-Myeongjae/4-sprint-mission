package com.sprint.mission.discodeit.entity;

public enum ChannelType {
    PUBLIC,
    PRIVATE,
}
