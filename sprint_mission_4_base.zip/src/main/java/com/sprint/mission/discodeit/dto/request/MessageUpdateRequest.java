package com.sprint.mission.discodeit.dto.request;

public record MessageUpdateRequest(
        String newContent
) {
}
