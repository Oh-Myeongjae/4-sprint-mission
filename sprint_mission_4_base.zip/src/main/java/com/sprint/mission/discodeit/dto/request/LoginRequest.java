package com.sprint.mission.discodeit.dto.request;

public record LoginRequest(
        String username,
        String password
) {
}
